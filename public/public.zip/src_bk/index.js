
import React from 'react';
import ReactDOM from 'react-dom';
import Add_Blog from './components/Add_Blog';
import Header from './components/Header';
import Footer from './components/Footer';
import NavBar from './components/NavBar';

ReactDOM.render(
  <div>
    <NavBar />
    <Header />
    <Add_Blog 
      url='/api/blogs'
      pollInterval={8000} 
    />
    <Footer />
  </div>
  ,
  document.getElementById('root')
);


